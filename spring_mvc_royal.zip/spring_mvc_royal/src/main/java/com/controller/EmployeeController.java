package com.controller;


import java.util.List;

import javax.swing.SwingContainer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bean.EmployeeBean;
import com.dao.EmployeeDao;

@Controller
public class EmployeeController{
	
//	
//	@RequestMapping("/dashboard")
//	public String dashBoard() {
//		 return "redirect:newdashboard";
//	}
//	
//	@RequestMapping("/newdashboard")
//	public String newDashboard() {
//		System.out.println("new dashboard called");
//		
//		return "home";
//	}
	
	
	@Autowired
	EmployeeDao employeeDao;
	
	
	@RequestMapping("/addemployee")
	
	
	public String addEmployee(Model model) {
		EmployeeBean employeeBean=new EmployeeBean();
		model.addAttribute("employeeBean",employeeBean);
		return "addEmployee";
	}
//	//@RequestMapping(value="insertemployee",method = RequestMethod.POST)
//	@PostMapping(value = "insertemployee")
//	public String insertEmployee(@RequestParam("txtEmployeeName") String eName,@RequestParam("txtEmployeeAge")String eAge) {
//		System.out.println("insert employee");
//		System.out.println(eName+" "+eAge);
//		return "home";
//	}
	@PostMapping(value = "/insertemployee")
	public String insertEmployee(EmployeeBean employeeBean) {
//		System.out.println(employeeBean.getEmployeeName());
//		System.out.println(employeeBean.geteAge());

		int res=employeeDao.addEmployee(employeeBean);
		if(res>0) {
			return "home";
		}
		
		return "home";
	}
	
	@GetMapping(value="/viewemployees")
	public String employeeList(Model model) {
		List<EmployeeBean> list=employeeDao.getAllEmployees();
		model.addAttribute("emplist",list);
		
		
		return "employeelist";
	}
	
	
}